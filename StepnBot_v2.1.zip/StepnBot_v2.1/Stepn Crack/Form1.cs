﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FakeCodeGenerator
{
    public partial class Form1 : Form
    {
        private static Random random = new Random();

        public static string RandomString(int length)
        {
            const string chars = "0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            generateButton.Visible = false;
            loadingBox.Visible = true;
            WaitSomeTime();
        }

        public async void WaitSomeTime()
        {
            await Task.Delay(4000);
            loadingBox.Visible = false;
            label1.Visible = true;
            textBox1.Visible = true;
            textBox1.Text = RandomString(8);
        }
    }
}
